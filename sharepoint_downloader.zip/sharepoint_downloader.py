
backup_root = r"C:\SharePointBackup"

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

import time
import os
import shutil
import urllib.parse


sharepoint_url = "PASTE_URL"


chrome_options = Options()
chrome_options.add_argument("--start-maximized")

chromedriver_path = "chromedriver.exe"

service = Service(chromedriver_path)

driver = webdriver.Chrome(service=service, options=chrome_options)


driver.get(sharepoint_url)

input("Login then press Enter...")


time.sleep(5)


def is_folder(href):
    return href and "#id=" in href.lower()


def downloads_dir():
    return os.path.join(os.path.expanduser("~"), "Downloads")


def download_file(name, href, folder_url, backup_folder):

    dst = os.path.join(backup_folder, name)

    if os.path.exists(dst):
        print("SKIP", name)
        return

    parsed = urllib.parse.urlparse(href)
    qs = urllib.parse.parse_qs(parsed.query)

    source_url = None

    if "sourceurl" in qs:
        source_url = qs["sourceurl"][0]

    if not source_url:

        folder_id = urllib.parse.parse_qs(
            urllib.parse.urlparse(folder_url).query
        ).get("id", [""])[0]

        folder_id = urllib.parse.unquote(folder_id)

        source_url = folder_id + "/" + name


    encoded = urllib.parse.quote(source_url, safe="")

    download_url = (
        "https://consumershare.apac.citi.net"
        "/_layouts/15/download.aspx?SourceUrl="
        + encoded
    )

    print("DOWNLOAD", name)

    driver.execute_script(
        f"window.open('{download_url}','_blank');"
    )

    time.sleep(5)

    src = os.path.join(downloads_dir(), name)

    if os.path.exists(src):
        shutil.move(src, dst)


def process_folder(folder_name, folder_url, depth=0, parent_path=""):

    if depth > 20:
        return

    current_path = os.path.join(parent_path, folder_name)

    backup_folder = os.path.join(
        backup_root,
        current_path
    )

    os.makedirs(backup_folder, exist_ok=True)

    print("OPEN", folder_name)

    driver.get(folder_url)

    time.sleep(3)

    rows = driver.find_elements(
        By.CSS_SELECTOR,
        '[role="row"]'
    )

    subfolders = []

    for row in rows:

        links = row.find_elements(
            By.CSS_SELECTOR,
            '[data-automationid="DetailsRowCell"] a'
        )

        if not links:
            continue

        link = links[0]

        name = link.text.strip()
        href = link.get_attribute("href")

        if not name or not href:
            continue

        if is_folder(href):

            subfolders.append((name, href))

        else:

            download_file(
                name,
                href,
                folder_url,
                backup_folder
            )

    for n, u in subfolders:

        process_folder(
            n,
            u,
            depth + 1,
            current_path
        )


rows = driver.find_elements(
    By.CSS_SELECTOR,
    '[role="row"]'
)

folders = []

for row in rows:

    links = row.find_elements(
        By.CSS_SELECTOR,
        '[data-automationid="DetailsRowCell"] a'
    )

    if not links:
        continue

    link = links[0]

    name = link.text
    href = link.get_attribute("href")

    if is_folder(href):

        folders.append((name, href))


if len(folders) > 2:

    name, url = folders[2]

    process_folder(name, url)

else:

    print("Not enough folders")


input("DONE")
driver.quit()
