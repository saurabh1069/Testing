
import time
import os
import shutil
import urllib.parse

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options


backup_root = r"C:\SharePointBackup"
sharepoint_url = "PASTE_URL"


parsed_site = urllib.parse.urlparse(sharepoint_url)
site_root = parsed_site.scheme + "://" + parsed_site.netloc
site_name = "/" + sharepoint_url.split("/", 3)[3].split("/")[0]

DOWNLOAD_BASE = site_root + site_name + "/_layouts/15/download.aspx?SourceUrl="


chrome_options = Options()
chrome_options.add_argument("--start-maximized")

service = Service("chromedriver.exe")

driver = webdriver.Chrome(service=service, options=chrome_options)

driver.get(sharepoint_url)

input("Login then press Enter")

time.sleep(5)


def is_folder(href):
    return href and "#id=" in href.lower()


def downloads_dir():
    return os.path.join(os.path.expanduser("~"), "Downloads")


def build_source(folder_url, name):

    folder_id = urllib.parse.parse_qs(
        urllib.parse.urlparse(folder_url).query
    ).get("id", [""])[0]

    if not folder_id:
        frag = urllib.parse.urlparse(folder_url).fragment
        if frag.startswith("id="):
            folder_id = frag[3:]

    folder_id = urllib.parse.unquote(folder_id).strip()

    if not folder_id.endswith("/"):
        folder_id += "/"

    return folder_id + name


def download_file(name, href, folder_url, backup):

    dst = os.path.join(backup, name)

    if os.path.exists(dst):
        print("SKIP", name)
        return

    source = build_source(folder_url, name)

    encoded = urllib.parse.quote(source, safe="")

    url = DOWNLOAD_BASE + encoded

    print("DOWNLOAD", url)

    driver.execute_script(
        f"window.open('{url}','_blank');"
    )

    time.sleep(5)

    src = os.path.join(downloads_dir(), name)

    if os.path.exists(src):
        shutil.move(src, dst)


def process_folder(name, url, parent=""):

    path = os.path.join(parent, name)

    backup = os.path.join(backup_root, path)

    os.makedirs(backup, exist_ok=True)

    print("OPEN", path)

    driver.get(url)

    time.sleep(3)

    rows = driver.find_elements(
        By.CSS_SELECTOR,
        '[role="row"]'
    )

    subs = []

    for r in rows:

        links = r.find_elements(
            By.CSS_SELECTOR,
            '[data-automationid="DetailsRowCell"] a'
        )

        if not links:
            continue

        link = links[0]

        n = link.text.strip()
        h = link.get_attribute("href")

        if not n or not h:
            continue

        if is_folder(h):

            subs.append((n, h))

        else:

            download_file(
                n,
                h,
                url,
                backup
            )

    for n, h in subs:

        process_folder(
            n,
            h,
            path
        )


rows = driver.find_elements(
    By.CSS_SELECTOR,
    '[role="row"]'
)

folders = []

for r in rows:

    links = r.find_elements(
        By.CSS_SELECTOR,
        '[data-automationid="DetailsRowCell"] a'
    )

    if not links:
        continue

    link = links[0]

    n = link.text
    h = link.get_attribute("href")

    if is_folder(h):

        folders.append((n, h))


if len(folders) > 2:

    process_folder(
        folders[2][0],
        folders[2][1]
    )

else:

    print("Not enough folders")


input("DONE")

driver.quit()
