"""Module 3 SLA Credit Request Service (local JSON-backed MVP)."""

from __future__ import annotations

import json
import os
import secrets
import hashlib
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("M3_DATA_DIR", str(BASE_DIR / "data")))
CLAIMS_FILE = DATA_DIR / "sla-claims.json"
NOTES_FILE = DATA_DIR / "sla-case-notes.json"
AUDIT_FILE = DATA_DIR / "sla-audit.json"
M4_CASE_DETAILS_FILE = DATA_DIR / "m4-case-details.json"
PORT = int(os.getenv("M3_PORT", "3003"))


def now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def identifier(prefix: str) -> str:
    return f"{prefix}-{secrets.token_hex(4).upper()}"


def ensure_store() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for file in (CLAIMS_FILE, NOTES_FILE, AUDIT_FILE, M4_CASE_DETAILS_FILE):
        if not file.exists():
            file.write_text("[]\n", encoding="utf-8")


def read_store(file: Path) -> list[dict[str, Any]]:
    return json.loads(file.read_text(encoding="utf-8"))


def write_store(file: Path, records: list[dict[str, Any]]) -> None:
    file.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")


def validate(payload: dict[str, Any]) -> list[str]:
    """M1/M2 field names are open-ended; only a non-empty JSON object is required."""
    return [] if isinstance(payload, dict) and payload else ["Each M1/M2 entry must be a non-empty JSON object"]


def find_value(payload: dict[str, Any], *names: str, default: Any = None) -> Any:
    """Use familiar names when available without enforcing either team's schema."""
    fields = {str(key).lower(): value for key, value in payload.items()}
    for name in names:
        if fields.get(name.lower()) not in (None, ""):
            return fields[name.lower()]
    return default


def source_fingerprint(payload: dict[str, Any]) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def build_microsoft_request(payload: dict[str, Any]) -> dict[str, Any]:
    """Mapping boundary: M1/M2 contract to the Microsoft-service contract."""
    incident_id = str(find_value(payload, "incidentId", "incident", "outageId", "outageReference", "caseId", default="Unknown incident"))
    service = str(find_value(payload, "service", "product", "platformName", "application", "applicationName", default="Microsoft 365"))
    description = find_value(payload, "description", "summary", "details", "decisionNotes")
    return {
        "requestId": str(find_value(payload, "requestId", "request_id", "id", default=identifier("SRC"))),
        "applicationId": str(find_value(payload, "applicationId", "application", "applicationName", default="Unknown application")),
        "vendor": {"name": str(find_value(payload, "vendorName", "vendor", "supplier", "provider", default="Unknown vendor"))},
        "incidentId": incident_id,
        "service": service,
        "creditPercentage": find_value(payload, "creditPercentage", "credit", "eligibleCredit"),
        "outageStart": find_value(payload, "outageStart", "startTime", "startDate"),
        "outageEnd": find_value(payload, "outageEnd", "endTime", "endDate"),
        "affectedUsers": find_value(payload, "affectedUsers", "usersAffected", "impactedEmployees"),
        "evidence": find_value(payload, "evidence", "attachments", default=[]),
        "severity": str(find_value(payload, "severity", "priority", default="Sev B")),
        "createdBy": str(find_value(payload, "createdBy", "owner", "submittedBy", default="M1/M2 automation")),
        "description": str(description or f"Service credit request for outage in {incident_id}"),
        "inputSummary": json.dumps(payload, sort_keys=True, default=str),
        "rawInput": payload,
    }


def mock_microsoft_submit(request: dict[str, Any]) -> dict[str, Any]:
    """Fake Microsoft adapter. Replace only this function for a real integration."""
    stamp = datetime.now(timezone.utc).strftime("%y%m%d")
    ticket_id = f"{stamp}142{secrets.randbelow(900000) + 100000}"
    return {
        "ticketId": ticket_id,
        "trackingId": ticket_id,
        "microsoftStatus": "Agent assigned",
        "businessStatus": "SUBMITTED",
        "createdDate": now(),
        "title": f"Service credit request for outage in {request['incidentId']}",
    }


def add_audit(claim_id: str, action: str, remarks: str) -> None:
    audits = read_store(AUDIT_FILE)
    audits.append({"auditId": identifier("AUD"), "claimId": claim_id, "action": action,
                   "timestamp": now(), "performedBy": "M3", "remarks": remarks})
    write_store(AUDIT_FILE, audits)


def create_m4_case_details(claim: dict[str, Any]) -> dict[str, Any]:
    """The stable JSON contract M4 consumes; it hides M3's internal storage format."""
    return {
        "caseId": claim["claimId"],
        "sourceRequestId": claim["requestId"],
        "sourceFingerprint": claim["sourceFingerprint"],
        "incidentId": claim["incidentId"],
        "applicationId": claim["applicationId"],
        "ticketId": claim["ticketId"],
        "trackingId": claim["trackingId"],
        "title": claim["title"],
        "description": claim["description"],
        "service": claim["service"],
        "product": claim["product"],
        "severity": claim["severity"],
        "microsoftStatus": claim["microsoftStatus"],
        "businessStatus": claim["businessStatus"],
        "submittedDate": claim["submittedDate"],
        "createdBy": claim["createdBy"],
        "creditPercentage": claim["creditPercentage"],
        "claimStatus": claim["claimStatus"],
        "inputSummary": claim["inputSummary"],
        "rawInput": claim["rawInput"],
    }


def publish_to_m4(claim: dict[str, Any]) -> dict[str, Any]:
    case_details = create_m4_case_details(claim)
    published = read_store(M4_CASE_DETAILS_FILE)
    if not any(item.get("sourceFingerprint") == claim["sourceFingerprint"] for item in published):
        published.append(case_details)
        write_store(M4_CASE_DETAILS_FILE, published)
    return case_details


def submit(payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    errors = validate(payload)
    if errors:
        return HTTPStatus.BAD_REQUEST, {"status": "VALIDATION_FAILED", "errors": errors}

    fingerprint = source_fingerprint(payload)
    claims = read_store(CLAIMS_FILE)
    existing = next((claim for claim in claims if claim.get("sourceFingerprint") == fingerprint), None)
    if existing:
        return HTTPStatus.CONFLICT, {"status": "ALREADY_CLAIMED", "claimId": existing["claimId"], "sourceFingerprint": fingerprint}

    request = build_microsoft_request(payload)
    microsoft = mock_microsoft_submit(request)
    claim = {
        "claimId": identifier("CLM"), "requestId": request["requestId"], "applicationId": request["applicationId"],
        "vendorName": request["vendor"]["name"], "incidentId": request["incidentId"], "service": request["service"],
        "creditPercentage": request["creditPercentage"], "title": microsoft["title"], "description": request["description"],
        "ticketId": microsoft["ticketId"], "trackingId": microsoft["trackingId"], "microsoftStatus": microsoft["microsoftStatus"],
        "businessStatus": microsoft["businessStatus"], "product": request["service"], "severity": request["severity"],
        "createdDate": microsoft["createdDate"], "submittedDate": now(), "createdBy": request["createdBy"], "closedDate": None,
        "outageStart": request["outageStart"], "outageEnd": request["outageEnd"], "affectedUsers": request["affectedUsers"], "evidence": request["evidence"],
        "claimStatus": "CLAIMED", "sourceFingerprint": fingerprint, "inputSummary": request["inputSummary"], "rawInput": request["rawInput"],
    }
    claims.append(claim)
    write_store(CLAIMS_FILE, claims)

    notes = read_store(NOTES_FILE)
    notes.append({"noteId": identifier("NOTE"), "claimId": claim["claimId"], "ticketId": claim["ticketId"],
                  "trackingId": claim["trackingId"], "subject": claim["title"],
                  "sender": "supportmail-eu@techsupport.microsoft.com", "receivedDate": now(),
                  "body": f"Mock Microsoft service request created. TrackingID#{claim['trackingId']}"})
    write_store(NOTES_FILE, notes)
    add_audit(claim["claimId"], "CLAIM_SUBMITTED", f"Mock Microsoft ticket {claim['ticketId']} created")
    publish_to_m4(claim)
    return HTTPStatus.CREATED, claim


class M3Handler(BaseHTTPRequestHandler):
    def send_json(self, status: int, body: Any) -> None:
        data = json.dumps(body, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_json(self) -> Any:
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self) -> None:  # noqa: N802
        try:
            parts = self.path.split("?")[0].strip("/").split("/")
            if self.path.split("?")[0] == "/health":
                return self.send_json(HTTPStatus.OK, {"service": "m3-sla-credit-request", "status": "ok"})
            if parts == ["api", "v1", "sla-claims"]:
                return self.send_json(HTTPStatus.OK, read_store(CLAIMS_FILE))
            if parts == ["api", "v1", "m4", "case-details"]:
                return self.send_json(HTTPStatus.OK, read_store(M4_CASE_DETAILS_FILE))
            if len(parts) == 5 and parts[:3] == ["api", "v1", "sla-claims"]:
                claim_id, resource = parts[3], parts[4]
                claim = next((item for item in read_store(CLAIMS_FILE) if item["claimId"] == claim_id), None)
                if not claim:
                    return self.send_json(HTTPStatus.NOT_FOUND, {"error": "Claim not found"})
                if resource == "status":
                    return self.send_json(HTTPStatus.OK, {key: claim[key] for key in ("claimId", "requestId", "ticketId", "trackingId", "microsoftStatus", "businessStatus", "closedDate")})
                if resource == "case-notes":
                    return self.send_json(HTTPStatus.OK, [note for note in read_store(NOTES_FILE) if note["claimId"] == claim_id])
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "Route not found"})
        except Exception as error:  # pragma: no cover
            print(error)
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "Internal server error"})

    def do_POST(self) -> None:  # noqa: N802
        try:
            payload = self.read_json()
            route = self.path.split("?")[0]
            if route == "/api/v1/sla-claims":
                if not isinstance(payload, dict):
                    return self.send_json(HTTPStatus.BAD_REQUEST, {"error": "A claim JSON object is required"})
                status, result = submit(payload)
                return self.send_json(status, result)
            if route == "/api/v1/sla-claims/import":
                inputs = payload if isinstance(payload, list) else payload.get("claims", [payload])
                results = []
                for item in inputs:
                    status, result = submit(item)
                    results.append({"ok": status == HTTPStatus.CREATED, "statusCode": status, "claim": result} if status == HTTPStatus.CREATED else {"ok": False, "statusCode": status, **result})
                response_status = HTTPStatus.MULTI_STATUS if any(not item["ok"] for item in results) else HTTPStatus.CREATED
                return self.send_json(response_status, {"results": results})
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "Route not found"})
        except (json.JSONDecodeError, ValueError) as error:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": f"Invalid JSON: {error}"})
        except Exception as error:  # pragma: no cover
            print(error)
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "Internal server error"})

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[M3] {self.address_string()} - {fmt % args}")


if __name__ == "__main__":
    ensure_store()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), M3Handler)
    print(f"M3 SLA Credit Request service listening on {PORT}")
    server.serve_forever()
