"""File-based M3 pipeline for teams that exchange JSON files instead of HTTP."""

import json
import sys
from pathlib import Path

import server


def main() -> None:
    input_path = Path(sys.argv[1]) if len(sys.argv) > 1 else server.DATA_DIR / "m1-m2-input.json"
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    inputs = payload if isinstance(payload, list) else payload.get("claims", [payload])
    server.ensure_store()

    results = []
    for claim in inputs:
        status, result = server.submit(claim)
        if status == 409:
            fingerprint = server.source_fingerprint(claim)
            existing = next(item for item in server.read_store(server.CLAIMS_FILE) if item.get("sourceFingerprint") == fingerprint)
            server.publish_to_m4(existing)
            result = {"message": "Existing M3 request reused and published for M4", "claim": existing}
            status = 200
        results.append({"statusCode": int(status), "result": result})

    print(json.dumps({
        "input": str(input_path),
        "m4Output": str(server.M4_CASE_DETAILS_FILE),
        "results": results,
    }, indent=2))


if __name__ == "__main__":
    main()
