# Module 3 — SLA Credit Request Service

This is a standalone Python MVP for Module 3. It accepts claim JSON from M1/M2, validates and maps it to a Microsoft-style request, calls a fake Microsoft adapter, then stores claims, case notes, and audit history as JSON files. It uses only the Python standard library.

It intentionally does not call the real Microsoft 365 portal or use browser automation. Replace `mock_microsoft_submit` in `server.py` with an approved Microsoft integration when one is available.

## High-level architecture

```mermaid
flowchart LR
    M1[M1: Incident / outage data] --> INPUT[M1/M2 JSON input file]
    M2[M2: Eligibility / credit decision] --> INPUT
    INPUT --> M3[M3 Python pipeline]
    M3 --> VALIDATE[Accept any JSON fields<br/>Preserve rawInput + inputSummary]
    VALIDATE --> DEDUPE{Fingerprint already claimed?}
    DEDUPE -- Yes --> REUSE[Reuse existing case<br/>No new dummy ticket]
    DEDUPE -- No --> MOCK[Dummy Microsoft API]
    MOCK --> TICKET[Generate random ticket ID<br/>and tracking ID]
    TICKET --> CLAIM[Store claimStatus: CLAIMED]
    REUSE --> M4OUT[M4 case-details JSON]
    CLAIM --> M4OUT
    M4OUT --> M4[M4 consumes case details]
    CLAIM --> INTERNAL[Internal JSON: claims, notes, audit]
```

M3 is schema-flexible: it accepts any non-empty JSON object from M1/M2. For each new object, it generates a random dummy Microsoft ticket and tracking ID. If the exact same object arrives again, its fingerprint matches an existing claim, so M3 reuses that case instead of creating another one.

## Start

From the repository root:

```powershell
python .\module3-service\server.py
```

The service listens on `http://localhost:3003`. Set `M3_PORT` or `M3_DATA_DIR` to override the port or JSON-storage directory.

Open `http://localhost:3003` in a browser to use the M3 dashboard. It presents the M1/M2 input as user-friendly business fields, the M3 claim register, and the M4-ready case results without exposing raw JSON.

## Input contract from M1/M2

M3 accepts any non-empty JSON object from M1/M2; there are no mandatory field names. It preserves the full received object as `rawInput` and creates `inputSummary` from every input field for M4.

When familiar fields are present—such as `incidentId`, `service`, `vendorName`, `severity`, or `creditPercentage`—M3 maps them into the Microsoft-style case. Otherwise it uses clear default values.

M3 calculates a SHA-256 fingerprint from each full input object. When the same object arrives again, it has already been claimed, so M3 does not create another dummy ticket. Any new object/fingerprint gets a new random dummy ticket/tracking ID and `claimStatus: "CLAIMED"`.

The sample input is in `data/m1-m2-input.json`.

## M1/M2 → M3 → dummy Microsoft → M4

1. The M1/M2 team provides one claim object, an array of claim objects, or `{ "claims": [...] }` in JSON.
2. M3 validates the M1/M2 fields and transforms them into the Microsoft request format.
3. M3 calls its `mock_microsoft_submit` adapter. This is the dummy replacement for a Microsoft API call; it returns a ticket ID, tracking ID, and `Agent assigned` status.
4. M3 persists its internal records in `sla-claims.json`, `sla-case-notes.json`, and `sla-audit.json`.
5. M3 publishes a clean M4 contract to `m4-case-details.json`. M4 should read this file (or the matching API endpoint) and does not need to know how M3 talks to Microsoft.

For file-to-file processing, copy the received M1/M2 JSON to `data/m1-m2-input.json` and run:

```powershell
python .\module3-service\run_pipeline.py
```

The command prints the exact path of M4's output file. To use a file from another location, pass it as an argument:

```powershell
python .\module3-service\run_pipeline.py 'C:\path\from-m1-m2\claims.json'
```

## API

- `POST /api/v1/sla-claims` — create one request.
- `POST /api/v1/sla-claims/import` — import a JSON array, `{ "claims": [...] }`, or one claim.
- `GET /api/v1/sla-claims` — list all persisted requests.
- `GET /api/v1/sla-claims/:claimId` — return a specific claim by ID.
- `GET /api/v1/sla-claims/:claimId/status` — return captured ticket/tracking and statuses.
- `GET /api/v1/sla-claims/:claimId/case-notes` — return the mock correspondence for a claim.
- `GET /api/v1/sla-claims/:claimId/audit` — return audit trail for a specific claim.
- `GET /api/v1/sla-case-notes` — list all correspondence notes across claims.
- `GET /api/v1/sla-audit` — list all audit trail records.
- `GET /api/v1/input-sample` — return latest or sample input data.
- `GET /api/v1/m4/case-details` — return the M4-ready case-details contract.
- `GET /health` — health check endpoint.

Example import:

```powershell
Invoke-RestMethod -Method Post -ContentType 'application/json' -InFile '.\module3-service\data\m1-m2-input.json' -Uri 'http://localhost:3003/api/v1/sla-claims/import'
```

JSON persistence is created automatically in the `data` folder: `sla-claims.json`, `sla-case-notes.json`, `sla-audit.json`, and the M4 handoff file `m4-case-details.json`.

