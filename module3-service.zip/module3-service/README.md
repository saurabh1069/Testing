# Module 3 — SLA Credit Request Service

The **Module 3 SLA Credit Request Service** is a lightweight, zero-dependency Python service that bridges upstream incident/eligibility decisions (M1/M2) with downstream tracking (M4) and service provider ticket management.

It ingests claims from M1/M2, performs deduplication via cryptographic fingerprinting, transforms payloads into Microsoft-compatible requests, simulates Microsoft ticket generation via a modular adapter, and produces a standardized contract consumed by Module 4.

---

## Architecture

### 1. End-to-End Workflow

```mermaid
flowchart TD
    M1["M1: Incident & Outage Data"] --> INPUT["M1/M2 Claim Payload<br/>(JSON File or HTTP)"]
    M2["M2: Eligibility & Credit Decision"] --> INPUT
    
    INPUT --> INGEST["M3 Ingestion & Validation<br/>(Schema-Flexible)"]
    INGEST --> FINGERPRINT["Calculate SHA-256 Fingerprint"]
    
    FINGERPRINT --> DEDUPE{"Already Claimed?"}
    
    DEDUPE -- "Yes (Duplicate)" --> REUSE["Reuse Existing Claim<br/>(Preserve Ticket & Tracking)"]
    REUSE --> PUBLISH["Upsert M4 Case Details"]
    
    DEDUPE -- "No (New)" --> MOCK["Microsoft Adapter<br/>(mock_microsoft_submit)"]
    MOCK --> TICKET["Generate Ticket ID & Tracking ID<br/>Status: Agent assigned"]
    TICKET --> STORE["Persist Internal Stores<br/>• sla-claims.json<br/>• sla-case-notes.json<br/>• sla-audit.json"]
    STORE --> PUBLISH
    
    PUBLISH --> M4["M4: Downstream Case Tracking<br/>(m4-case-details.json)"]
```

### 2. Service & Component Architecture

```mermaid
graph TB
    subgraph Client Layer
        UI["Web Dashboard<br/>(dashboard.html)"]
        CLI["Pipeline CLI<br/>(run_pipeline.py)"]
        HTTP_CLIENT["External HTTP Client<br/>(Postman / PowerShell / cURL)"]
    end

    subgraph Service Layer ["Module 3 Service (server.py)"]
        ROUTER["HTTP Request Handler<br/>(M3Handler)"]
        VALIDATOR["Validator & Mapper<br/>(build_microsoft_request)"]
        DEDUPE_ENGINE["Fingerprint Engine<br/>(SHA-256)"]
        ADAPTER["Microsoft Adapter<br/>(mock_microsoft_submit)"]
        M4_PUBLISHER["M4 Publisher<br/>(publish_to_m4)"]
    end

    subgraph Persistence Layer ["Local JSON Storage (data/)"]
        IN_FILE["m1-m2-input.json / latest-m1-m2-input.json"]
        CLAIMS_FILE["sla-claims.json"]
        NOTES_FILE["sla-case-notes.json"]
        AUDIT_FILE["sla-audit.json"]
        M4_FILE["m4-case-details.json"]
    end

    UI -->|"GET / · GET /health<br/>POST /api/v1/sla-claims/import"| ROUTER
    HTTP_CLIENT -->|"REST API (GET / POST / OPTIONS)"| ROUTER
    CLI -->|"Direct Python Ingestion"| VALIDATOR

    ROUTER --> VALIDATOR
    VALIDATOR --> DEDUPE_ENGINE
    DEDUPE_ENGINE --> ADAPTER
    ADAPTER --> M4_PUBLISHER

    ROUTER --> IN_FILE
    VALIDATOR --> CLAIMS_FILE
    ADAPTER --> NOTES_FILE
    ADAPTER --> AUDIT_FILE
    M4_PUBLISHER --> M4_FILE
```

---

## How to Compile, Test & Run

This project requires **Python 3.8+** and uses **only Python standard library modules** (`http.server`, `json`, `hashlib`, `secrets`, `pathlib`, `unittest`). No `pip install` is required.

### 1. Compile & Syntax Check

To verify syntax and compile bytecode for all files:

```powershell
python -m py_compile server.py run_pipeline.py test_server.py
```

### 2. Run Automated Test Suite

Run the full suite of unit and integration tests:

```powershell
python -m unittest test_server.py -v
```

All 14 tests will execute, validating:
- Schema-flexible field mapping and data validation
- SHA-256 fingerprinting and duplicate claim detection
- Full REST API endpoints (GET, POST, OPTIONS) and CORS headers
- Fault-tolerant JSON store reading and legacy record compatibility
- CLI file pipeline execution

### 3. Start the HTTP Backend Service

From within `module3-service`:

```powershell
python .\server.py
```

Or from the repository root:

```powershell
python .\module3-service\server.py
```

The service will output:
```
M3 SLA Credit Request service listening on 3003
```

#### Environment Variables
| Variable | Default | Description |
| :--- | :--- | :--- |
| `M3_PORT` | `3003` | Port number for the HTTP server |
| `M3_DATA_DIR` | `<dir>/data` | Directory for JSON persistence files |

### 4. Run the File Pipeline (CLI Mode)

To process files directly without running the HTTP server:

```powershell
# Run with default input (data/m1-m2-input.json)
python .\run_pipeline.py

# Run with a custom input file
python .\run_pipeline.py "C:\path\to\custom-claims.json"
```

---

## Interactive HTML Dashboard Reference

The service includes a built-in, responsive single-page dashboard (`dashboard.html`) designed for business users and operators to review upstream data, check service connectivity, and trigger claim generation without exposing raw JSON.

### Accessing the Dashboard

1. Start the server (`python server.py`).
2. Open your browser to: **[http://localhost:3003](http://localhost:3003)**
3. Alternatively, launch it from PowerShell:
   ```powershell
   Start-Process "http://localhost:3003"
   ```

### 3-Step Operator Workflow

```
[ Step 1: Load input data ]  --->  [ Step 2: Check M3 service ]  --->  [ Step 3: Generate dummy claim ]
```

1. **Step 1: Load M1 and M2 data**
   - Calls `GET /api/v1/input-sample`.
   - Formats raw JSON inputs into clear business cards (Request ID, Application, Vendor, Incident, Service, Outage Window, Eligible Credit, Evidence).
2. **Step 2: Start M3 processing**
   - Calls `GET /health` to confirm server availability and readiness.
   - Activates a green status indicator and enables claim generation.
3. **Step 3: Generate claim**
   - Posts loaded data to `POST /api/v1/sla-claims/import`.
   - Contacts the mock Microsoft adapter, assigns ticket/tracking numbers, stores audit logs, and outputs M4 case records.
   - Employs **duplicate protection**: repeated inputs safely reuse existing claims rather than creating duplicate tickets.

---

## REST API Reference

All API responses return JSON and include CORS headers (`Access-Control-Allow-Origin: *`).

| Method | Endpoint | Description | Status Code |
| :--- | :--- | :--- | :--- |
| `GET` | `/` | Serves the HTML operational dashboard | `200 OK` |
| `GET` | `/health` | Service health status check | `200 OK` |
| `GET` | `/api/v1/input-sample` | Returns latest or sample input data | `200 OK` |
| `GET` | `/api/v1/sla-claims` | Lists all persisted claims | `200 OK` |
| `GET` | `/api/v1/sla-claims/:claimId` | Returns a specific claim by ID | `200 OK` / `404 Not Found` |
| `GET` | `/api/v1/sla-claims/:claimId/status` | Returns ticket, tracking, and status | `200 OK` / `404 Not Found` |
| `GET` | `/api/v1/sla-claims/:claimId/case-notes` | Returns correspondence notes for a claim | `200 OK` / `404 Not Found` |
| `GET` | `/api/v1/sla-claims/:claimId/audit` | Returns audit trail records for a claim | `200 OK` / `404 Not Found` |
| `GET` | `/api/v1/sla-case-notes` | Lists all correspondence notes across claims | `200 OK` |
| `GET` | `/api/v1/sla-audit` | Lists all audit trail records | `200 OK` |
| `GET` | `/api/v1/m4/case-details` | Returns M4-ready case details contract | `200 OK` |
| `POST` | `/api/v1/sla-claims` | Submits a single claim object | `201 Created` / `409 Conflict` |
| `POST` | `/api/v1/sla-claims/import` | Imports an array or `{ "claims": [...] }` | `201 Created` / `207 Multi-Status` |
| `OPTIONS`| `/*` | CORS preflight handler | `204 No Content` |

### Example API Request (PowerShell)

```powershell
Invoke-RestMethod -Method Post -ContentType 'application/json' `
  -InFile '.\data\m1-m2-input.json' `
  -Uri 'http://localhost:3003/api/v1/sla-claims/import'
```

---

## Data Storage & Contracts

All data files are stored in the `data/` directory:

| File | Purpose |
| :--- | :--- |
| `m1-m2-input.json` | Sample input file demonstrating varied upstream schemas from M1/M2. |
| `latest-m1-m2-input.json` | Most recently imported input payload (powers the dashboard). |
| `sla-claims.json` | Internal register of all created claims with tickets, tracking, and timestamps. |
| `sla-case-notes.json` | Simulated provider communication log for each claim. |
| `sla-audit.json` | Comprehensive audit trail logging every action and state transition. |
| `m4-case-details.json` | Clean handoff contract consumed by Module 4. |

### Module 4 Handoff Contract (`m4-case-details.json`)

```json
{
  "caseId": "CLM-5EC53AA1",
  "sourceRequestId": "REQ-12345",
  "sourceFingerprint": "e44e44ff0b493adaf7c90d1d8f67a493f307fa37baac77eaab8b305a861579e7",
  "incidentId": "CW1447067",
  "applicationId": "APP-1001",
  "ticketId": "260824142784777",
  "trackingId": "260824142784777",
  "title": "Service credit request for outage in CW1447067",
  "description": "Service credit request for outage in CW1447067",
  "service": "Billing and Subscriptions",
  "product": "Billing and Subscriptions",
  "severity": "Sev B",
  "microsoftStatus": "Agent assigned",
  "businessStatus": "SUBMITTED",
  "submittedDate": "2026-08-24T16:13:08.484909Z",
  "createdBy": "M1/M2 automation",
  "creditPercentage": 75,
  "claimStatus": "CLAIMED",
  "inputSummary": "{...}",
  "rawInput": { ... }
}
```
