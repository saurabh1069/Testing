"""File-based M3 pipeline for teams that exchange JSON files instead of HTTP."""

import json
import sys
from pathlib import Path

import server


def main() -> None:
    input_path = Path(sys.argv[1]) if len(sys.argv) > 1 else server.DATA_DIR / "m1-m2-input.json"
    if not input_path.exists():
        print(json.dumps({
            "error": f"Input file not found: {input_path}",
            "statusCode": 404,
        }, indent=2), file=sys.stderr)
        sys.exit(1)

    try:
        payload = json.loads(input_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(json.dumps({
            "error": f"Failed to parse JSON from {input_path}: {e}",
            "statusCode": 400,
        }, indent=2), file=sys.stderr)
        sys.exit(1)

    if isinstance(payload, list):
        inputs = payload
    elif isinstance(payload, dict):
        raw_claims = payload.get("claims", [payload])
        inputs = raw_claims if isinstance(raw_claims, list) else [raw_claims]
    else:
        inputs = [payload]

    server.ensure_store()
    server.write_store(server.LATEST_INPUT_FILE, inputs)

    results = []
    for claim in inputs:
        if not isinstance(claim, dict) or not claim:
            results.append({
                "statusCode": 400,
                "result": {"status": "VALIDATION_FAILED", "errors": ["Each M1/M2 entry must be a non-empty JSON object"]}
            })
            continue
        status, result = server.submit(claim)
        if status == 409:
            fingerprint = server.source_fingerprint(claim)
            existing = next((item for item in server.read_store(server.CLAIMS_FILE) if item.get("sourceFingerprint") == fingerprint), None)
            if existing:
                server.publish_to_m4(existing)
                result = {"message": "Existing M3 request reused and published for M4", "claim": existing}
                status = 200
        results.append({"statusCode": int(status), "result": result})

    print(json.dumps({
        "input": str(input_path),
        "m4Output": str(server.M4_CASE_DETAILS_FILE),
        "results": results,
    }, indent=2))


if __name__ == "__main__":
    main()
