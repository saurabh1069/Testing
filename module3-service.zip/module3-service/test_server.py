"""Unit and integration tests for Module 3 Service."""

import json
import os
import shutil
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http import HTTPStatus
from http.server import ThreadingHTTPServer
from pathlib import Path

import server
import run_pipeline


class TestModule3Unit(unittest.TestCase):
    def setUp(self) -> None:
        self.test_dir = Path(tempfile.mkdtemp(prefix="m3_unit_test_"))
        self.orig_data_dir = server.DATA_DIR
        self.orig_claims_file = server.CLAIMS_FILE
        self.orig_notes_file = server.NOTES_FILE
        self.orig_audit_file = server.AUDIT_FILE
        self.orig_m4_file = server.M4_CASE_DETAILS_FILE
        self.orig_latest_file = server.LATEST_INPUT_FILE
        self.orig_sample_file = server.SAMPLE_INPUT_FILE

        server.DATA_DIR = self.test_dir
        server.CLAIMS_FILE = self.test_dir / "sla-claims.json"
        server.NOTES_FILE = self.test_dir / "sla-case-notes.json"
        server.AUDIT_FILE = self.test_dir / "sla-audit.json"
        server.M4_CASE_DETAILS_FILE = self.test_dir / "m4-case-details.json"
        server.LATEST_INPUT_FILE = self.test_dir / "latest-m1-m2-input.json"
        server.SAMPLE_INPUT_FILE = self.test_dir / "m1-m2-input.json"
        server.ensure_store()

    def tearDown(self) -> None:
        server.DATA_DIR = self.orig_data_dir
        server.CLAIMS_FILE = self.orig_claims_file
        server.NOTES_FILE = self.orig_notes_file
        server.AUDIT_FILE = self.orig_audit_file
        server.M4_CASE_DETAILS_FILE = self.orig_m4_file
        server.LATEST_INPUT_FILE = self.orig_latest_file
        server.SAMPLE_INPUT_FILE = self.orig_sample_file
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_validate(self) -> None:
        self.assertEqual(server.validate({"incidentId": "INC-1"}), [])
        self.assertTrue(len(server.validate({})) > 0)
        self.assertTrue(len(server.validate([])) > 0)  # type: ignore
        self.assertTrue(len(server.validate("invalid")) > 0)  # type: ignore

    def test_find_value(self) -> None:
        payload = {"IncidentID": "INC-99", "service": "Teams", "credit": 50}
        self.assertEqual(server.find_value(payload, "incidentId"), "INC-99")
        self.assertEqual(server.find_value(payload, "product", "service"), "Teams")
        self.assertEqual(server.find_value(payload, "missing", default="default_val"), "default_val")

    def test_source_fingerprint_deterministic(self) -> None:
        payload1 = {"b": 2, "a": 1}
        payload2 = {"a": 1, "b": 2}
        self.assertEqual(server.source_fingerprint(payload1), server.source_fingerprint(payload2))

    def test_read_store_resilience(self) -> None:
        corrupted_file = self.test_dir / "corrupted.json"
        corrupted_file.write_text("invalid json content {{{", encoding="utf-8")
        self.assertEqual(server.read_store(corrupted_file), [])

        empty_file = self.test_dir / "empty.json"
        empty_file.write_text("", encoding="utf-8")
        self.assertEqual(server.read_store(empty_file), [])

        missing_file = self.test_dir / "nonexistent.json"
        self.assertEqual(server.read_store(missing_file), [])

    def test_create_m4_case_details_legacy_compatibility(self) -> None:
        # Legacy claim without sourceFingerprint, claimStatus, inputSummary, rawInput
        legacy_claim = {
            "claimId": "CLM-LEGACY01",
            "requestId": "REQ-123",
            "incidentId": "INC-LEGACY",
            "applicationId": "APP-01",
            "ticketId": "260800111222",
            "trackingId": "260800111222",
            "title": "Legacy Service Credit",
            "description": "Legacy credit description",
            "service": "Billing",
            "microsoftStatus": "Agent assigned",
            "businessStatus": "SUBMITTED",
            "submittedDate": "2026-08-20T00:00:00Z",
        }
        details = server.create_m4_case_details(legacy_claim)
        self.assertEqual(details["caseId"], "CLM-LEGACY01")
        self.assertIsNone(details["sourceFingerprint"])
        self.assertEqual(details["claimStatus"], "CLAIMED")
        self.assertEqual(details["service"], "Billing")
        self.assertEqual(details["product"], "Billing")

    def test_submit_and_deduplication(self) -> None:
        payload = {
            "incidentId": "INC-TEST-101",
            "service": "Exchange Online",
            "creditPercentage": 50,
            "vendorName": "Microsoft",
        }
        status, claim = server.submit(payload)
        self.assertEqual(status, HTTPStatus.CREATED)
        self.assertTrue(claim["claimId"].startswith("CLM-"))
        self.assertEqual(claim["incidentId"], "INC-TEST-101")
        self.assertEqual(claim["service"], "Exchange Online")

        # Second submission of identical payload should be 409 CONFLICT
        status_dup, dup_res = server.submit(payload)
        self.assertEqual(status_dup, HTTPStatus.CONFLICT)
        self.assertEqual(dup_res["status"], "ALREADY_CLAIMED")
        self.assertEqual(dup_res["claimId"], claim["claimId"])

        # Check audit and case notes
        audits = server.read_store(server.AUDIT_FILE)
        self.assertTrue(any(a["claimId"] == claim["claimId"] for a in audits))

        notes = server.read_store(server.NOTES_FILE)
        self.assertTrue(any(n["claimId"] == claim["claimId"] for n in notes))

        # Check published M4 case details
        m4_details = server.read_store(server.M4_CASE_DETAILS_FILE)
        self.assertTrue(any(m["caseId"] == claim["claimId"] for m in m4_details))


class TestModule3HttpApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.test_dir = Path(tempfile.mkdtemp(prefix="m3_http_test_"))
        server.DATA_DIR = cls.test_dir
        server.CLAIMS_FILE = cls.test_dir / "sla-claims.json"
        server.NOTES_FILE = cls.test_dir / "sla-case-notes.json"
        server.AUDIT_FILE = cls.test_dir / "sla-audit.json"
        server.M4_CASE_DETAILS_FILE = cls.test_dir / "m4-case-details.json"
        server.LATEST_INPUT_FILE = cls.test_dir / "latest-m1-m2-input.json"
        server.SAMPLE_INPUT_FILE = cls.test_dir / "m1-m2-input.json"
        server.ensure_store()

        cls.sample_data = [
            {"incidentId": "INC-001", "service": "SharePoint", "creditPercentage": 25},
            {"incidentId": "INC-002", "service": "Teams", "creditPercentage": 50},
        ]
        server.SAMPLE_INPUT_FILE.write_text(json.dumps(cls.sample_data), encoding="utf-8")

        # Pick an ephemeral free port by binding to 0
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), server.M3Handler)
        cls.port = cls.server.server_port
        cls.base_url = f"http://127.0.0.1:{cls.port}"

        cls.server_thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.server_thread.start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        shutil.rmtree(cls.test_dir, ignore_errors=True)

    def make_request(
        self,
        path: str,
        method: str = "GET",
        data: dict | list | None = None,
        headers: dict | None = None,
    ) -> tuple[int, dict | list | str, dict]:
        url = f"{self.base_url}{path}"
        req_headers = headers or {}
        body = None
        if data is not None:
            body = json.dumps(data).encode("utf-8")
            req_headers["Content-Type"] = "application/json"

        req = urllib.request.Request(url, data=body, headers=req_headers, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                status = resp.status
                resp_headers = dict(resp.headers)
                content = resp.read().decode("utf-8")
                try:
                    return status, json.loads(content), resp_headers
                except Exception:
                    return status, content, resp_headers
        except urllib.error.HTTPError as e:
            status = e.code
            resp_headers = dict(e.headers)
            content = e.read().decode("utf-8")
            try:
                return status, json.loads(content), resp_headers
            except Exception:
                return status, content, resp_headers

    def setUp(self) -> None:
        server.ensure_store()
        server.write_store(server.CLAIMS_FILE, [])
        server.write_store(server.NOTES_FILE, [])
        server.write_store(server.AUDIT_FILE, [])
        server.write_store(server.M4_CASE_DETAILS_FILE, [])
        if server.LATEST_INPUT_FILE.exists():
            server.LATEST_INPUT_FILE.unlink()
        server.SAMPLE_INPUT_FILE.write_text(json.dumps(self.sample_data), encoding="utf-8")

    def test_health(self) -> None:
        status, body, _ = self.make_request("/health")
        self.assertEqual(status, 200)
        self.assertEqual(body, {"service": "m3-sla-credit-request", "status": "ok"})

    def test_dashboard_html(self) -> None:
        for path in ("/", "/dashboard.html", "/index.html", "/dashboard", "/ui"):
            status, body, headers = self.make_request(path)
            self.assertEqual(status, 200, f"Failed for path {path}")
            self.assertIn("M3 | SLA Credit Request Automation", str(body))
            self.assertIn("text/html", headers.get("Content-Type", ""))

    def test_proxy_prefix_routing(self) -> None:
        # Test routing behind corporate proxy prefixes (e.g. /m3/ or /module3-service/)
        status, body, _ = self.make_request("/m3/health")
        self.assertEqual(status, 200)
        self.assertEqual(body.get("status"), "ok")

        status, body, _ = self.make_request("/module3-service/api/v1/sla-claims")
        self.assertEqual(status, 200)
        self.assertIsInstance(body, list)

    def test_input_sample(self) -> None:
        # Initially returns sample data (2 items)
        status, body, _ = self.make_request("/api/v1/input-sample")
        self.assertEqual(status, 200)
        self.assertIsInstance(body, list)
        self.assertEqual(len(body), 2)

        # After importing new data, returns the latest input
        new_input = [{"incidentId": "INC-NEW", "service": "Exchange", "creditPercentage": 30}]
        self.make_request("/api/v1/sla-claims/import", method="POST", data=new_input)
        status, updated_body, _ = self.make_request("/api/v1/input-sample")
        self.assertEqual(status, 200)
        self.assertEqual(len(updated_body), 1)
        self.assertEqual(updated_body[0]["incidentId"], "INC-NEW")

    def test_options_cors(self) -> None:
        status, _, headers = self.make_request("/api/v1/sla-claims", method="OPTIONS")
        self.assertEqual(status, 204)
        self.assertEqual(headers.get("Access-Control-Allow-Origin"), "*")
        self.assertIn("GET", headers.get("Access-Control-Allow-Methods", ""))

    def test_crud_claim_lifecycle(self) -> None:
        claim_payload = {
            "incidentId": "INC-HTTP-5001",
            "service": "Azure DevOps",
            "creditPercentage": 100,
            "vendorName": "Microsoft",
            "affectedUsers": 300,
        }

        # 1. Create claim
        status, claim, headers = self.make_request("/api/v1/sla-claims", method="POST", data=claim_payload)
        self.assertEqual(status, 201)
        self.assertEqual(headers.get("Access-Control-Allow-Origin"), "*")
        claim_id = claim["claimId"]
        self.assertTrue(claim_id.startswith("CLM-"))

        # 2. Get list of claims
        status, claims_list, _ = self.make_request("/api/v1/sla-claims")
        self.assertEqual(status, 200)
        self.assertTrue(any(c["claimId"] == claim_id for c in claims_list))

        # 3. Get single claim by ID
        status, single_claim, _ = self.make_request(f"/api/v1/sla-claims/{claim_id}")
        self.assertEqual(status, 200)
        self.assertEqual(single_claim["claimId"], claim_id)
        self.assertEqual(single_claim["incidentId"], "INC-HTTP-5001")

        # 4. Get status by ID
        status, status_info, _ = self.make_request(f"/api/v1/sla-claims/{claim_id}/status")
        self.assertEqual(status, 200)
        self.assertEqual(status_info["claimId"], claim_id)
        self.assertEqual(status_info["microsoftStatus"], "Agent assigned")

        # 5. Get case notes by claim ID
        status, notes, _ = self.make_request(f"/api/v1/sla-claims/{claim_id}/case-notes")
        self.assertEqual(status, 200)
        self.assertTrue(len(notes) >= 1)
        self.assertEqual(notes[0]["claimId"], claim_id)

        # 6. Get audit by claim ID
        status, audits, _ = self.make_request(f"/api/v1/sla-claims/{claim_id}/audit")
        self.assertEqual(status, 200)
        self.assertTrue(len(audits) >= 1)
        self.assertEqual(audits[0]["claimId"], claim_id)

        # 7. Get global audit and notes
        status, all_audits, _ = self.make_request("/api/v1/sla-audit")
        self.assertEqual(status, 200)
        self.assertTrue(len(all_audits) >= 1)

        status, all_notes, _ = self.make_request("/api/v1/sla-case-notes")
        self.assertEqual(status, 200)
        self.assertTrue(len(all_notes) >= 1)

        # 8. Get M4 case details
        status, m4_cases, _ = self.make_request("/api/v1/m4/case-details")
        self.assertEqual(status, 200)
        self.assertTrue(any(m["caseId"] == claim_id for m in m4_cases))

        # 9. Non-existent claim
        status, not_found, _ = self.make_request("/api/v1/sla-claims/CLM-NONEXISTENT")
        self.assertEqual(status, 404)
        self.assertEqual(not_found["error"], "Claim not found")

    def test_import_endpoint(self) -> None:
        batch = [
            {"incidentId": "INC-IMP-1", "service": "Power BI", "creditPercentage": 10},
            {"incidentId": "INC-IMP-2", "service": "Intune", "creditPercentage": 20},
        ]
        status, res, _ = self.make_request("/api/v1/sla-claims/import", method="POST", data=batch)
        self.assertEqual(status, 201)
        self.assertEqual(len(res["results"]), 2)
        self.assertTrue(all(r["ok"] for r in res["results"]))

        # Importing again with same data -> 207 Multi-Status with ALREADY_CLAIMED
        status_dup, res_dup, _ = self.make_request("/api/v1/sla-claims/import", method="POST", data=batch)
        self.assertEqual(status_dup, 207)
        self.assertEqual(len(res_dup["results"]), 2)
        self.assertTrue(all(r["statusCode"] == 409 for r in res_dup["results"]))

    def test_import_invalid_payloads(self) -> None:
        # Non-dict/non-list primitive should return 400 Bad Request
        status, res, _ = self.make_request("/api/v1/sla-claims/import", method="POST", data=12345)  # type: ignore
        self.assertEqual(status, 400)
        self.assertIn("error", res)

        # Empty array
        status, res, _ = self.make_request("/api/v1/sla-claims/import", method="POST", data=[])
        self.assertEqual(status, 400)

        # Array with invalid items
        status, res, _ = self.make_request("/api/v1/sla-claims/import", method="POST", data=["invalid_item"])  # type: ignore
        self.assertEqual(status, 207)
        self.assertFalse(res["results"][0]["ok"])
        self.assertEqual(res["results"][0]["statusCode"], 400)


class TestPipelineScript(unittest.TestCase):
    def setUp(self) -> None:
        self.test_dir = Path(tempfile.mkdtemp(prefix="m3_pipeline_test_"))
        self.orig_data_dir = server.DATA_DIR
        self.orig_claims_file = server.CLAIMS_FILE
        self.orig_notes_file = server.NOTES_FILE
        self.orig_audit_file = server.AUDIT_FILE
        self.orig_m4_file = server.M4_CASE_DETAILS_FILE
        self.orig_latest_file = server.LATEST_INPUT_FILE
        self.orig_sample_file = server.SAMPLE_INPUT_FILE

        server.DATA_DIR = self.test_dir
        server.CLAIMS_FILE = self.test_dir / "sla-claims.json"
        server.NOTES_FILE = self.test_dir / "sla-case-notes.json"
        server.AUDIT_FILE = self.test_dir / "sla-audit.json"
        server.M4_CASE_DETAILS_FILE = self.test_dir / "m4-case-details.json"
        server.LATEST_INPUT_FILE = self.test_dir / "latest-m1-m2-input.json"
        server.SAMPLE_INPUT_FILE = self.test_dir / "m1-m2-input.json"
        server.ensure_store()

    def tearDown(self) -> None:
        server.DATA_DIR = self.orig_data_dir
        server.CLAIMS_FILE = self.orig_claims_file
        server.NOTES_FILE = self.orig_notes_file
        server.AUDIT_FILE = self.orig_audit_file
        server.M4_CASE_DETAILS_FILE = self.orig_m4_file
        server.LATEST_INPUT_FILE = self.orig_latest_file
        server.SAMPLE_INPUT_FILE = self.orig_sample_file
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_pipeline_file_execution(self) -> None:
        input_data = [
            {"incidentId": "INC-PIPE-1", "service": "OneDrive", "creditPercentage": 50}
        ]
        input_file = self.test_dir / "test-input.json"
        input_file.write_text(json.dumps(input_data), encoding="utf-8")

        # Run pipeline by mocking sys.argv
        import sys
        orig_argv = sys.argv
        try:
            sys.argv = ["run_pipeline.py", str(input_file)]
            run_pipeline.main()
        finally:
            sys.argv = orig_argv

        # Check results published to m4
        m4_details = server.read_store(server.M4_CASE_DETAILS_FILE)
        self.assertEqual(len(m4_details), 1)
        self.assertEqual(m4_details[0]["incidentId"], "INC-PIPE-1")


if __name__ == "__main__":
    unittest.main()
